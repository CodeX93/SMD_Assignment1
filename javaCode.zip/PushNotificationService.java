//package com.example.i200778AghaHaider;
//
//import com.google.firebase.messaging.FirebaseMessagingService;
//
//public class PushNotificationService  extends FirebaseMessagingService {
//
//
//    public void onTokenRefresh() {
//        // Get updated InstanceID token.
//
//        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
//        Log.d(TAG, "Refreshed token: " + refreshedToken);
//
//        // If you want to send messages to this application instance or
//        // manage this apps subscriptions on the server side, send the
//        // Instance ID token to your app server.
//        sendRegistrationToServer(refreshedToken);
//    }
//
//}
